/********************************************************************************
** Form generated from reading UI file 'changervitesse.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHANGERVITESSE_H
#define UI_CHANGERVITESSE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_ChangerVitesse
{
public:
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer;
    QLabel *lTitre;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *verticalSpacer_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *lNvelleVitesse;
    QSpinBox *sNvelleVitesse;
    QSpacerItem *horizontalSpacer_3;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *bAnnuler;
    QPushButton *bValider;

    void setupUi(QDialog *ChangerVitesse)
    {
        if (ChangerVitesse->objectName().isEmpty())
            ChangerVitesse->setObjectName(QString::fromUtf8("ChangerVitesse"));
        ChangerVitesse->resize(285, 146);
        verticalLayout_2 = new QVBoxLayout(ChangerVitesse);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer);

        lTitre = new QLabel(ChangerVitesse);
        lTitre->setObjectName(QString::fromUtf8("lTitre"));
        QFont font;
        font.setPointSize(12);
        lTitre->setFont(font);

        horizontalLayout_3->addWidget(lTitre);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_2);

        horizontalLayout_3->setStretch(0, 1);
        horizontalLayout_3->setStretch(1, 2);
        horizontalLayout_3->setStretch(2, 1);

        verticalLayout->addLayout(horizontalLayout_3);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        lNvelleVitesse = new QLabel(ChangerVitesse);
        lNvelleVitesse->setObjectName(QString::fromUtf8("lNvelleVitesse"));

        horizontalLayout_2->addWidget(lNvelleVitesse);

        sNvelleVitesse = new QSpinBox(ChangerVitesse);
        sNvelleVitesse->setObjectName(QString::fromUtf8("sNvelleVitesse"));
        sNvelleVitesse->setBaseSize(QSize(0, 0));
        sNvelleVitesse->setMinimum(1);
        sNvelleVitesse->setValue(1);

        horizontalLayout_2->addWidget(sNvelleVitesse);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);

        horizontalLayout_2->setStretch(0, 1);
        horizontalLayout_2->setStretch(1, 1);

        verticalLayout->addLayout(horizontalLayout_2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_4);

        bAnnuler = new QPushButton(ChangerVitesse);
        bAnnuler->setObjectName(QString::fromUtf8("bAnnuler"));

        horizontalLayout->addWidget(bAnnuler);

        bValider = new QPushButton(ChangerVitesse);
        bValider->setObjectName(QString::fromUtf8("bValider"));

        horizontalLayout->addWidget(bValider);


        verticalLayout->addLayout(horizontalLayout);

        verticalLayout->setStretch(0, 1);
        verticalLayout->setStretch(2, 1);
        verticalLayout->setStretch(4, 1);

        verticalLayout_2->addLayout(verticalLayout);


        retranslateUi(ChangerVitesse);

        QMetaObject::connectSlotsByName(ChangerVitesse);
    } // setupUi

    void retranslateUi(QDialog *ChangerVitesse)
    {
        ChangerVitesse->setWindowTitle(QCoreApplication::translate("ChangerVitesse", "Dialog", nullptr));
        lTitre->setText(QCoreApplication::translate("ChangerVitesse", "Changer la vitesse de lecture", nullptr));
        lNvelleVitesse->setText(QCoreApplication::translate("ChangerVitesse", "Nouvelle vitesse ", nullptr));
        bAnnuler->setText(QCoreApplication::translate("ChangerVitesse", "Annuler", nullptr));
        bValider->setText(QCoreApplication::translate("ChangerVitesse", "Valider", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ChangerVitesse: public Ui_ChangerVitesse {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHANGERVITESSE_H
