/********************************************************************************
** Form generated from reading UI file 'lecteurvue.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LECTEURVUE_H
#define UI_LECTEURVUE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LecteurVue
{
public:
    QAction *aQuitter;
    QAction *aEnleverDiapo;
    QAction *aChangerVitesse;
    QAction *aAPropos;
    QAction *aChargerDiapo;
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_2;
    QLabel *lNomDiapo;
    QLabel *lVitesseLecture;
    QLabel *lRepVitesse;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_5;
    QLabel *lImage;
    QGridLayout *gridLayout;
    QLabel *lTitre;
    QLabel *lRang;
    QLabel *lCategorie;
    QLabel *lTitreRep;
    QLabel *lCategorieRep;
    QLabel *lRangRep;
    QSpacerItem *verticalSpacer_2;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *bPrecedent;
    QPushButton *bSuivant;
    QSpacerItem *horizontalSpacer_6;
    QSpacerItem *horizontalSpacer;
    QPushButton *bArreterDiapo;
    QPushButton *bLancerDiapo;
    QSpacerItem *horizontalSpacer_4;
    QMenuBar *menubar;
    QMenu *menuFichier;
    QMenu *menuParam_tres;
    QMenu *menuAide;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *LecteurVue)
    {
        if (LecteurVue->objectName().isEmpty())
            LecteurVue->setObjectName(QString::fromUtf8("LecteurVue"));
        LecteurVue->resize(466, 277);
        aQuitter = new QAction(LecteurVue);
        aQuitter->setObjectName(QString::fromUtf8("aQuitter"));
        aEnleverDiapo = new QAction(LecteurVue);
        aEnleverDiapo->setObjectName(QString::fromUtf8("aEnleverDiapo"));
        aChangerVitesse = new QAction(LecteurVue);
        aChangerVitesse->setObjectName(QString::fromUtf8("aChangerVitesse"));
        aAPropos = new QAction(LecteurVue);
        aAPropos->setObjectName(QString::fromUtf8("aAPropos"));
        aChargerDiapo = new QAction(LecteurVue);
        aChargerDiapo->setObjectName(QString::fromUtf8("aChargerDiapo"));
        centralwidget = new QWidget(LecteurVue);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);

        lNomDiapo = new QLabel(centralwidget);
        lNomDiapo->setObjectName(QString::fromUtf8("lNomDiapo"));
        QFont font;
        font.setFamilies({QString::fromUtf8("Arial")});
        font.setPointSize(16);
        font.setBold(true);
        lNomDiapo->setFont(font);

        horizontalLayout->addWidget(lNomDiapo);

        lVitesseLecture = new QLabel(centralwidget);
        lVitesseLecture->setObjectName(QString::fromUtf8("lVitesseLecture"));
        QFont font1;
        font1.setPointSize(12);
        lVitesseLecture->setFont(font1);

        horizontalLayout->addWidget(lVitesseLecture);

        lRepVitesse = new QLabel(centralwidget);
        lRepVitesse->setObjectName(QString::fromUtf8("lRepVitesse"));
        lRepVitesse->setFont(font1);

        horizontalLayout->addWidget(lRepVitesse);

        horizontalLayout->setStretch(1, 3);
        horizontalLayout->setStretch(2, 1);

        verticalLayout->addLayout(horizontalLayout);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_5);

        lImage = new QLabel(centralwidget);
        lImage->setObjectName(QString::fromUtf8("lImage"));

        horizontalLayout_3->addWidget(lImage);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        lTitre = new QLabel(centralwidget);
        lTitre->setObjectName(QString::fromUtf8("lTitre"));
        lTitre->setFont(font1);

        gridLayout->addWidget(lTitre, 0, 0, 1, 1);

        lRang = new QLabel(centralwidget);
        lRang->setObjectName(QString::fromUtf8("lRang"));
        lRang->setFont(font1);

        gridLayout->addWidget(lRang, 3, 0, 1, 1);

        lCategorie = new QLabel(centralwidget);
        lCategorie->setObjectName(QString::fromUtf8("lCategorie"));
        lCategorie->setFont(font1);

        gridLayout->addWidget(lCategorie, 2, 0, 1, 1);

        lTitreRep = new QLabel(centralwidget);
        lTitreRep->setObjectName(QString::fromUtf8("lTitreRep"));

        gridLayout->addWidget(lTitreRep, 0, 1, 1, 1);

        lCategorieRep = new QLabel(centralwidget);
        lCategorieRep->setObjectName(QString::fromUtf8("lCategorieRep"));

        gridLayout->addWidget(lCategorieRep, 2, 1, 1, 1);

        lRangRep = new QLabel(centralwidget);
        lRangRep->setObjectName(QString::fromUtf8("lRangRep"));

        gridLayout->addWidget(lRangRep, 3, 1, 1, 1);


        horizontalLayout_3->addLayout(gridLayout);

        horizontalLayout_3->setStretch(1, 1);
        horizontalLayout_3->setStretch(2, 1);

        verticalLayout->addLayout(horizontalLayout_3);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);

        bPrecedent = new QPushButton(centralwidget);
        bPrecedent->setObjectName(QString::fromUtf8("bPrecedent"));

        horizontalLayout_2->addWidget(bPrecedent);

        bSuivant = new QPushButton(centralwidget);
        bSuivant->setObjectName(QString::fromUtf8("bSuivant"));

        horizontalLayout_2->addWidget(bSuivant);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_6);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        bArreterDiapo = new QPushButton(centralwidget);
        bArreterDiapo->setObjectName(QString::fromUtf8("bArreterDiapo"));

        horizontalLayout_2->addWidget(bArreterDiapo);

        bLancerDiapo = new QPushButton(centralwidget);
        bLancerDiapo->setObjectName(QString::fromUtf8("bLancerDiapo"));

        horizontalLayout_2->addWidget(bLancerDiapo);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_4);

        horizontalLayout_2->setStretch(1, 1);
        horizontalLayout_2->setStretch(2, 1);
        horizontalLayout_2->setStretch(4, 1);
        horizontalLayout_2->setStretch(5, 1);
        horizontalLayout_2->setStretch(6, 1);

        verticalLayout->addLayout(horizontalLayout_2);

        LecteurVue->setCentralWidget(centralwidget);
        menubar = new QMenuBar(LecteurVue);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 466, 22));
        menuFichier = new QMenu(menubar);
        menuFichier->setObjectName(QString::fromUtf8("menuFichier"));
        menuParam_tres = new QMenu(menubar);
        menuParam_tres->setObjectName(QString::fromUtf8("menuParam_tres"));
        menuAide = new QMenu(menubar);
        menuAide->setObjectName(QString::fromUtf8("menuAide"));
        LecteurVue->setMenuBar(menubar);
        statusbar = new QStatusBar(LecteurVue);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        statusbar->setEnabled(true);
        QFont font2;
        font2.setBold(false);
        statusbar->setFont(font2);
        statusbar->setAutoFillBackground(false);
        statusbar->setSizeGripEnabled(true);
        LecteurVue->setStatusBar(statusbar);

        menubar->addAction(menuFichier->menuAction());
        menubar->addAction(menuParam_tres->menuAction());
        menubar->addAction(menuAide->menuAction());
        menuFichier->addAction(aQuitter);
        menuParam_tres->addAction(aChangerVitesse);
        menuParam_tres->addAction(aChargerDiapo);
        menuParam_tres->addAction(aEnleverDiapo);
        menuAide->addAction(aAPropos);

        retranslateUi(LecteurVue);

        QMetaObject::connectSlotsByName(LecteurVue);
    } // setupUi

    void retranslateUi(QMainWindow *LecteurVue)
    {
        LecteurVue->setWindowTitle(QCoreApplication::translate("LecteurVue", "LecteurVue", nullptr));
        aQuitter->setText(QCoreApplication::translate("LecteurVue", "Quitter", nullptr));
        aEnleverDiapo->setText(QCoreApplication::translate("LecteurVue", "Enlever le diaporama", nullptr));
        aChangerVitesse->setText(QCoreApplication::translate("LecteurVue", "Vitesse de d\303\251filement", nullptr));
        aAPropos->setText(QCoreApplication::translate("LecteurVue", "A propos de...", nullptr));
        aChargerDiapo->setText(QCoreApplication::translate("LecteurVue", "Charger le diaporama", nullptr));
        lNomDiapo->setText(QCoreApplication::translate("LecteurVue", "Nom du diaporama", nullptr));
        lVitesseLecture->setText(QCoreApplication::translate("LecteurVue", "Vitesse de lecture :", nullptr));
        lRepVitesse->setText(QString());
        lImage->setText(QString());
        lTitre->setText(QCoreApplication::translate("LecteurVue", "Titre :", nullptr));
        lRang->setText(QCoreApplication::translate("LecteurVue", "Rang :", nullptr));
        lCategorie->setText(QCoreApplication::translate("LecteurVue", "Cat\303\251gorie :", nullptr));
        lTitreRep->setText(QString());
        lCategorieRep->setText(QString());
        lRangRep->setText(QString());
        bPrecedent->setText(QCoreApplication::translate("LecteurVue", "Pr\303\251c\303\251dent", nullptr));
        bSuivant->setText(QCoreApplication::translate("LecteurVue", "Suivant", nullptr));
        bArreterDiapo->setText(QCoreApplication::translate("LecteurVue", "Arr\303\252ter le diaporama", nullptr));
        bLancerDiapo->setText(QCoreApplication::translate("LecteurVue", "Lancer le diaporama", nullptr));
        menuFichier->setTitle(QCoreApplication::translate("LecteurVue", "Fichier", nullptr));
        menuParam_tres->setTitle(QCoreApplication::translate("LecteurVue", "Param\303\250tres", nullptr));
        menuAide->setTitle(QCoreApplication::translate("LecteurVue", "Aide", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LecteurVue: public Ui_LecteurVue {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LECTEURVUE_H
