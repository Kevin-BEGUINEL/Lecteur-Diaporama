#ifndef DIAPO_H
#define DIAPO_H

#include "image.h"

typedef vector<Image*> Diaporama;   // Structure de données contenant les infos sur les images

class Diapo
{
public:
    Diapo(unsigned int pId=1,
          string pTitre="", unsigned int pVitesse=1);
    ~Diapo();
    unsigned int getId();
    string getTitre();
    int getVitesse();
    void setId(unsigned int);
    void setTitre(string);
    void setVitesse(int);

private:
    unsigned int _id;
    string _titre;
    unsigned int _vitesse;

};


#endif // DIAPO_H
