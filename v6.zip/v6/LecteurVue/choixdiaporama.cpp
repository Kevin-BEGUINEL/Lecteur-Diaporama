#include "choixdiaporama.h"
#include "ui_choixdiaporama.h"

ChoixDiaporama::ChoixDiaporama(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ChoixDiaporama)
{
    ui->setupUi(this);

    _modif = false;

    Database *db = new Database();
    db->openDataBase();

    QSqlQuery query;
    query.exec("SELECT * FROM Diaporamas ORDER BY idDiaporama");

    int ligneCourante = 0;
    while (query.next())
    {

        // on insère les résultats dans le tableau
        ui->tableWidget->insertRow(ligneCourante);
        QTableWidgetItem *element = new QTableWidgetItem(query.value(1).toString());
        ui->tableWidget->setItem(ligneCourante, 0,element);

        ligneCourante+=1;
    }


    // faire les connexions des boutons
    QObject::connect(ui->bValider, SIGNAL(clicked()), this, SLOT(valider()));
    QObject::connect(ui->bAnnuler, SIGNAL(clicked()), this, SLOT(close()));
}

ChoixDiaporama::~ChoixDiaporama()
{
    delete ui;
}

int ChoixDiaporama::getDiaporama()
{
        qDebug() << _choixDiapo;
    return _choixDiapo;
}

void ChoixDiaporama::setDiaporama()
{
    _choixDiapo = ui->tableWidget->currentRow()+1;
}

bool ChoixDiaporama::getModif()
{
    return _modif;
}

void ChoixDiaporama::setModif()
{
    _modif = true;
}

void ChoixDiaporama::valider()
{
    setDiaporama();
    setModif();
    close();
}
