/********************************************************************************
** Form generated from reading UI file 'choixdiaporama.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHOIXDIAPORAMA_H
#define UI_CHOIXDIAPORAMA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_ChoixDiaporama
{
public:
    QHBoxLayout *horizontalLayout_3;
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *verticalLayout;
    QLabel *lTitre;
    QTableWidget *tableWidget;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *bValider;
    QPushButton *bAnnuler;

    void setupUi(QDialog *ChoixDiaporama)
    {
        if (ChoixDiaporama->objectName().isEmpty())
            ChoixDiaporama->setObjectName(QString::fromUtf8("ChoixDiaporama"));
        ChoixDiaporama->resize(559, 282);
        horizontalLayout_3 = new QHBoxLayout(ChoixDiaporama);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        lTitre = new QLabel(ChoixDiaporama);
        lTitre->setObjectName(QString::fromUtf8("lTitre"));
        QFont font;
        font.setFamilies({QString::fromUtf8("Arial")});
        font.setPointSize(14);
        font.setBold(true);
        lTitre->setFont(font);
        lTitre->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(lTitre);

        tableWidget = new QTableWidget(ChoixDiaporama);
        if (tableWidget->columnCount() < 1)
            tableWidget->setColumnCount(1);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));

        verticalLayout->addWidget(tableWidget);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        bValider = new QPushButton(ChoixDiaporama);
        bValider->setObjectName(QString::fromUtf8("bValider"));

        horizontalLayout->addWidget(bValider);

        bAnnuler = new QPushButton(ChoixDiaporama);
        bAnnuler->setObjectName(QString::fromUtf8("bAnnuler"));

        horizontalLayout->addWidget(bAnnuler);


        verticalLayout->addLayout(horizontalLayout);


        horizontalLayout_2->addLayout(verticalLayout);


        horizontalLayout_3->addLayout(horizontalLayout_2);


        retranslateUi(ChoixDiaporama);

        QMetaObject::connectSlotsByName(ChoixDiaporama);
    } // setupUi

    void retranslateUi(QDialog *ChoixDiaporama)
    {
        ChoixDiaporama->setWindowTitle(QCoreApplication::translate("ChoixDiaporama", "Dialog", nullptr));
        lTitre->setText(QCoreApplication::translate("ChoixDiaporama", "Choix du diaporama", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("ChoixDiaporama", "titre du diaporama", nullptr));
        bValider->setText(QCoreApplication::translate("ChoixDiaporama", "Valider", nullptr));
        bAnnuler->setText(QCoreApplication::translate("ChoixDiaporama", "Annuler", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ChoixDiaporama: public Ui_ChoixDiaporama {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHOIXDIAPORAMA_H
