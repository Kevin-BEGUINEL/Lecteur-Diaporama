#ifndef CHOIXDIAPORAMA_H
#define CHOIXDIAPORAMA_H

#include <QDialog>
#include <QSqlQuery>

#include "database.h"
#include "diapo.h"

namespace Ui {
class ChoixDiaporama;
}

class ChoixDiaporama : public QDialog
{
    Q_OBJECT

public:
    explicit ChoixDiaporama(QWidget *parent = nullptr);
    ~ChoixDiaporama();
    int getDiaporama();
    void setDiaporama();
    bool getModif();
    void setModif();

private:
    Ui::ChoixDiaporama *ui;
    Diapo * _diapo;
    int _choixDiapo;
    bool _modif;
    // devient vrai si l'utilisateur choisie un diapo et le valide. Faux par défaut


private slots:
    void valider();
};

#endif // CHOIXDIAPORAMA_H
