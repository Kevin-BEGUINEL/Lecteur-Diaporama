#include "diapo.h"

Diapo::Diapo(unsigned int pId, string pTitre, unsigned int pVitesse)
{
    _id = pId;
    _titre = pTitre;
    _vitesse = pVitesse;
}

Diapo::~Diapo()
{

}


unsigned int Diapo::getId()
{
    return _id;
}

string Diapo::getTitre()
{
    return _titre;
}

int Diapo::getVitesse()
{
    return _vitesse;
}

void Diapo::setId(unsigned int pId)
{
    _id = pId;
}

void Diapo::setTitre(string pTitre)
{
    _titre = pTitre;
}

void Diapo::setVitesse(int pVitesse)
{
    _vitesse = pVitesse;
}
